import sys
import numpy as np
import mpmath as mpm
from math import exp
import matplotlib.pyplot as plt

def main():
### Main variables, etc. ######################################################
    T           = float(sys.argv[1])
    file_name   = sys.argv[2]
    alpha       = 1.0   # hbar * omega / k_B
    lam         = 1/2
    lO2         = lam / np.sqrt(alpha/2)
    eps         = np.sqrt( alpha/2 )/ T * 1.0   # hbar/T * sqrt(alpha/2)

    sinhEps     = mpm.sinh(eps)
    cothEps     = mpm.coth(eps)
    denom       = 1/np.sqrt(mpm.coth(eps/2)*np.pi/lO2)
    x_a = -3.0
    x_b = 3.0

    # Read input file
    with open(file_name,"r") as f:
        raw_data = f.read().splitlines()
    f.close()
    
    # Create variables and solve for exact answer
    M = 100
    u = np.linspace(x_a,x_b,M)
    v = np.linspace(x_a,x_b,M)
    rho = np.zeros([M,M])
    
    for i in range(M):
        for j in range(M):
            rho[i][j] = denom * exp( 1/(2*lO2) * (-cothEps * (u[i]*u[i] + v[j]*v[j]) + 2*u[i]*v[j]/sinhEps))
    
    trace = np.zeros_like(u)
    for k in range(M):
        trace[k]  = rho[k][k]

### Do some binning for x^2 ###################################################
    N = len(raw_data) - 1
    numBins = 20
    
    data = np.zeros(N)
    for m in range(N):
        data[m] = float(raw_data[m])
    datMax = max(data)
    datMin = min(data)
    binDelta = (datMax - datMin) / numBins
    print(f"binDelta = {binDelta}")

    x = np.linspace(0.0,x_b,numBins)
    y = np.zeros_like(x)
    for m in range(numBins):
        x[m] += binDelta/2

    binLoc = -1
    for l in range(N):
        binLoc = int(data[l] / binDelta)
        binLoc = binLoc if (binLoc < numBins) else (numBins - 1)
        y[binLoc] += 1
    y /= N
    print(f"x = {x}")
    print(f"y = {y}")
    
### Plot results ##############################################################
    fig = plt.figure()
    plt.plot(u,trace,'r--')
    plt.plot(x,y,'b.')
    plt.xlabel("x")
    plt.ylabel("rho")
    plt.show()

if __name__ == "__main__":
    main()
