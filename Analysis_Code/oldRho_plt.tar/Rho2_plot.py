import sys
import numpy as np
import mpmath as mpm
from math import exp
import matplotlib.pyplot as plt
import argparse, pathlib

def create_parser():
    parser = argparse.ArgumentParser(description='Temperature-dependent graphing of x1 and/or x2 data.',
            formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('temp', type=float, help="Temperature of the data")
    parser.add_argument("-x1", "--x1Data", type=pathlib.Path, help="File containing x1 data")
    parser.add_argument("-x2", "--x2Data", type=pathlib.Path, help="File containing x2 data")

    return parser

def main(argv=None):
### Main variables, etc. ######################################################
    if argv is None:
        argv = sys.argv
    
    parser = create_parser()
    args = parser.parse_args(argv[1:])

    T           = args.temp
    alpha       = 1.0   # hbar * omega / k_B
    lam         = 1/2
    lO2         = lam / np.sqrt(alpha/2)
    eps         = np.sqrt( alpha/2 )/ T * 1.0   # hbar/T * sqrt(alpha/2)

    sinhEps     = mpm.sinh(eps)
    cothEps     = mpm.coth(eps)
    denom       = 1/np.sqrt(mpm.coth(eps/2)*np.pi/lO2)

    x1_dat_name = sys.argv[2]
    x2_dat_name = sys.argv[3]
    # Read input file
    with open(x1_dat_name,"r") as f:
        raw_x1_dat = f.read().splitlines()
    f.close()
    print(f"len(X1) = {len(raw_x1_dat)}")
    with open(x2_dat_name,"r") as g:
        raw_x2_dat = g.read().splitlines()
    g.close()

    # Create variables and solve for exact answer
    M = len(raw_x1_dat)
    s = np.zeros(M)
    t = np.zeros(M)
    for a in range(M):
        s[a] = float(raw_x1_dat[a])
        t[a] = float(raw_x2_dat[a])
    
    x_a = min(s)
    x_b = max(s)
    
    n = 100
    u = np.linspace(x_a,x_b,n)
    v = np.linspace(x_a,x_b,n)
    rho = np.zeros([n,n])
    compRho = np.zeros([n,n])
    
    for i in range(n):
        for j in range(n):
            rho[i][j] = denom * exp( 1/(2*lO2) * (-cothEps * (u[i]*u[i] + v[j]*v[j]) + 2*u[i]*v[j]/sinhEps))
            compRho[i][j] = denom * exp( 1/(2*lO2) * (-cothEps * (s[i]*s[i] + t[j]*t[j]) + 2*s[i]*t[j]/sinhEps))
    traceSum = np.zeros(n)
    rho2 = 0.0
    for p in range(n):
        traceSum[p] += traceSum[p-1] + rho[p][p]
        rho2 += rho[p][p]*rho[p][p]

    trace = np.zeros_like(u)
    compTrace = np.zeros_like(u)
    for k in range(n):
        trace[k]  = rho[k][k]/rho2   #(x_b - x_a)*rho[k][k]/n
        compTrace[k] = compRho[k][k]
    print(f"traceSum = {np.sum(trace)}")
### Do some binning for x^2 ###################################################
    numBins = 51
    binDelta = (x_b - x_a)/numBins
    print(f"min = {min(s)}")
    print(f"max = {max(s)}")
    print(f"binDelta = {binDelta}")
    x = np.linspace(x_a,x_b,numBins) + binDelta/2
    y = np.zeros_like(x)
#    z = np.zeros_like(x)

    binLoc = 0
    for l in range(M):
        binLoc = int(s[l] / binDelta + numBins/2)
        if binLoc >= numBins: 
            binLoc = numBins - 1
        elif binLoc < 0: 
            binLoc = 0
        y[binLoc] += 1
#        binLoc = int(t[l] / binDelta + numBins/2)
#        z[binLoc] += 1
#    norm = np.sqrt(np.dot(y,y))
    norm = ( M )
    y /= (norm)
#    z /= 20
    yStdErr = np.zeros_like(y)
    for m in range(numBins):
        yStdErr[m] = np.sqrt(y[m]/norm)
    
    sum = np.zeros_like(x)
    for n in range(numBins):
            sum[n] += sum[n-1] + y[n]*binDelta

    print(f"sum = {sum[-1]}")
### Plot results ##############################################################
    fig = plt.figure()
    plt.plot(u,trace,'r--')
#    plt.bar(x, y, width=binDelta, edgecolor='black', yerr=yStdErr)
    plt.errorbar(x, y, yerr=yStdErr, fmt='b.')
#    plt.plot(s, compTrace, 'g.')
#    plt.hist(s, bins=numBins, density=True)
#    plt.plot(x,y,'b.')
    plt.title(fr"Counts and $\rho$ vs Position at {T} K")
    plt.xlabel("x (L)")
    plt.ylabel(r"Counts (arb.) or $\rho$ (1/L)")
    plt.show()

if __name__ == "__main__":
    main()
